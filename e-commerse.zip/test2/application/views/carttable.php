<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
</head>
<body>
<form method="post" action="<?=base_url('backend/order')?>">     
<table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Product Name</th>
            <th scope="col">Product Price</th>
            <th scope="col">Product Image</th>
            <th scope="col">Quntity</th>
            
            </tr>
        </thead>
        <tbody>
           
          
           <?php $i=1;?>
            <?php 

              foreach($result as $key=>$res)
               {
            ?>
            <tr>
            
            <input type="hidden" name="<?='item'?>[<?=$key?>][<?=$key?>][<?='id'?>]" value="<?=$res->product_id?>"> 
            <input type="hidden" name="<?='item'?>[<?=$key?>][<?=$key?>][<?='product_price'?>]" value="<?=$res->product_price?>"> 
            <th ><?=$i++;?></th>
            <td><?=$res->product_name?></td>
            <td><?=$res->product_price?></td>
            <td><img src="<?php echo base_url('images/').$res->product_image ?>" style="height:20%;width:20%;"></td>
            <td><input type="number" name="<?='item'?>[<?=$key?>][<?=$key?>][<?='quntity'?>]" value="<?=1;?>"></td>
            </tr>
           
            <?php
               }
             ?>
             
           
        </tbody>
        </table>
        <div style="margin-left:20px;" class="col-sm-3">
            <lable><strong>Address</strong></lable>
            <input name="address" type="text" class="form-control">
        </div>
        <br>
        <div class="col-sm-3" style="margin-left:20px;" >
        <select class="form-select" name="payment_method" id="payment_method">
          <option selected>select payment</option>
          <option value="UPI">UPI</option>
          <option value="NET BANKING">NET BANKING</option>
          <option value="WALLET">WALLET</option>
        </select>
        </div>
        <br>
        <button style="margin-left:50%;" class="btn btn-primary" type="submit">Process To CheckOut</button>
        </form>
</body>
</html>