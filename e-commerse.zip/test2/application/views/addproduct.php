<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
</head>
<body>
      <div align="center" style="margin-top:20px;" class="container">
          <div class="card" align="center" style="width:24rem;">
              <form method="post" action="<?=base_url('backend/addproductdata');?>" enctype="multipart/form-data">
                  <div class="col-sm-6">
                    <lable><strong>Product Name</strong></lable>
                     <input type="text" name="p_name" class="form-control">
                  </div>

                  <div class="col-sm-6">
                    <lable><strong>Product Price</strong></lable>
                     <input type="text" name="p_price" class="form-control">
                  </div>

                  <div class="col-sm-6">
                    <lable><strong>Product Image</strong></lable>
                     <input type="file" name="p_image" class="form-control">
                  </div>

                  <div class="col-sm-6">
                    <lable><strong>Product Description</strong></lable>
                     <input type="text" name="p_description" class="form-control">
                  </div>

                   <button class="btn btn-primary" type="submit">Add</button>
              </form>
          </div>
      </div>
</body>
</html>