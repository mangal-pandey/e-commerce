<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
</head>
<body>
<div style="margin-top:25px;" align="center" class="container">
          <div align="center" class="card" style="width: 28rem;" >
               <form method="post" action="<?=base_url('backend/logindata')?>" enctype="multipart/form-data" data-parsley-validate>
                  
                   <div class="col-sm-8">
                     <lable><strong>Email</strong></lable>
                      <input type="text" name="email" value="<?php echo set_value('email'); ?>" class="form-control" required>
                     <?php echo form_error('email'); ?>
                   </div>
                   <div class="col-sm-8">
                     <lable><strong>Password</strong></lable>
                      <input type="text" name="password" value="<?php echo set_value('password'); ?>" class="form-control" required>
                     <?php echo form_error('password'); ?>
                   </div>
                    <button class="btn btn-success" type="submit" name="submit">Submit</button>
               </form>
          </div>
     </div>
</body>
</html>