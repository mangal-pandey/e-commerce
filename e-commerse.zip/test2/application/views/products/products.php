<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
</head>
<body>
<table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Product Name</th>
            <th scope="col">Product Price</th>
            <th scope="col">Product Description</th>
            <th scope="col">Product Image</th>
            <th scope="col">Add Cart</th>
            
            </tr>
        </thead>
        <tbody>
            <?php $i=1;?>
            <?php 
              foreach($result as $res)
               {
            ?>
            <form method="post" action="<?= base_url('backend/addtocart')?>">
            <tr>
              <input type="hidden" name="product_id" value="<?= $res->id;?>">  
              <input type="hidden" name="product_name" value="<?= $res->name;?>"> 
              <input type="hidden" name="product_price" value="<?= $res->price;?>"> 
              <input type="hidden" name="product_image" value="<?= $res->image;?>">  
            <th ><?=$i++;?></th>
            <td><?=$res->name?></td>
            <td><?=$res->price?></td>
            <td><?=$res->description?></td>
            <td><img src="<?php echo base_url('images/').$res->image ?>" style="height:20%;width:20%;"></td>
            <td><button class="btn btn-success" type="submit">Add Cart</></td>
            </tr>
            </form>
            <?php
               }
             ?>
        </tbody>
        </table>
</body>
</html>