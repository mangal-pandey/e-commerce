<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js" integrity="sha512-eyHL1atYNycXNXZMDndxrDhNAegH2BDWt1TmkXJPoGf1WLlNYt08CSjkqF5lnCRmdm3IrkHid8s2jOUY4NIZVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>
<body>
     <div style="margin-top:25px;" align="center" class="container">
          <div align="center" class="card" style="width: 28rem;" >
               <form method="post" action="<?=base_url('backend/registrationdata')?>" enctype="multipart/form-data" data-parsley-validate>
                   <div class="col-sm-8">
                       <lable><strong>Name</strong></lable>
                      <input type="text" name="name" value="<?php echo set_value('name'); ?>" class="form-control" required>
                     <?php echo form_error('name'); ?>
                   </div>
                   <div class="col-sm-8">
                     <lable><strong>Email</strong></lable>
                      <input type="text" name="email" value="<?php echo set_value('email'); ?>" class="form-control" required>
                     <?php echo form_error('email'); ?>
                   </div>
                   <div class="col-sm-8">
                     <lable><strong>Mobile</strong></lable>
                      <input type="text" name="mobile" value="<?php echo set_value('mobile'); ?>" class="form-control" required>
                     <?php echo form_error('mobile'); ?>
                   </div>
                   <div class="col-sm-8">
                     <lable><strong>Address</strong></lable>
                      <input type="text" name="address" value="<?php echo set_value('address'); ?>" class="form-control" required>
                     <?php echo form_error('address'); ?>
                   </div>
                   <div class="col-sm-8">
                     <lable><strong>Password</strong></lable>
                      <input type="text" name="password" value="<?php echo set_value('password'); ?>" class="form-control" required>
                     <?php echo form_error('password'); ?>
                   </div>
                   <div class="col-sm-8">
                     <lable><strong>Image</strong></lable>
                      <input type="File" name="image" class="form-control">
                   </div>
                    <button class="btn btn-success" type="submit" name="submit">Submit</button>
               </form>
          </div>
     </div>
</body>
</html>
<script>
    jQuery(document).ready(function ($) {
        $('form').parsley();
    });
</script>