<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>
        <nav class="navbar navbar-expand-lg navbar-success bg-success">
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
               
                <a class="nav-item nav-link active" href="<?=base_url('backend/index')?>" style="font-size:18px;color:white;">Home</a>
                
               <?php 
                 if(!isset($_SESSION['user_id']) and !isset($_SESSION['admin_id']) )
                  {
                ?>
                  <a class="nav-item nav-link" href="<?=base_url('backend/registration')?>" style="font-size:18px;color:white;" >Registration</a>
                <?php 
                  }
                 ?>
                 <?php
                  if(!isset($_SESSION['user_id'])  and !isset($_SESSION['admin_id']))
                    {
                  ?>
                <a class="nav-item nav-link" href="<?=base_url('backend/login')?>" style="font-size:18px;color:white;">Login</a>
                <?php 
                  }
                 ?> 
                <?php
                if(isset($_SESSION['admin_id']))
                    {
                  ?>
                    <a class="nav-item nav-link" href="<?=base_url('backend/addproduct')?>" style="font-size:18px;color:white;" >Admin Product</a>
                <?php 
                  }
                 ?> 
                 <?php
                if(isset($_SESSION['user_id']))
                    {
                  ?>
                    <a class="nav-item nav-link" href="<?=base_url('backend/products')?>" style="font-size:18px;color:white;" > Products</a>
                <?php 
                  }
                 ?> 
                  
                  <?php
                if(isset($_SESSION['user_id']))
                    {
                  ?>
                    <a class="nav-item nav-link" href="<?=base_url('backend/cart')?>" style="font-size:18px;color:white;" >Cart</a>
                <?php 
                  }
                 ?> 

<?php
                if(isset($_SESSION['user_id']))
                    {
                  ?>
                    <a class="nav-item nav-link" href="<?=base_url('backend/orders')?>" style="font-size:18px;color:white;" >Orders</a>
                <?php 
                  }
                 ?> 


               <?php
                if(isset($_SESSION['admin_id']))
                    {
                  ?>
                    <a class="nav-item nav-link" href="<?=base_url('backend/producttable')?>" style="font-size:18px;color:white;" >Product Table</a>
                <?php 
                  }
                 ?> 

               <?php
                if(isset($_SESSION['admin_id']) or isset($_SESSION['user_id']) )
                    {
                  ?>
                    <a class="nav-item nav-link" href="<?=base_url('backend/logout')?>" style="font-size:18px;color:white;margin-left:800px;" >Logout</a>
                <?php 
                  }
                 ?> 
                 
                </div>
            </div>
        </nav>

 <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-info">
        <?php echo $_SESSION['success']; ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger">
        <?php echo $_SESSION['error']; ?>
    </div>
<?php endif; ?>

</body>
</html>