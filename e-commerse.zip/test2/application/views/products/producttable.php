<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Product Name</th>
            <th scope="col">Product Price</th>
            <th scope="col">Product Description</th>
            <th scope="col">Product Image</th>
            <th scope="col">Update</th>
            <th scope="col">Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $i=1;?>
            <?php 
              foreach($result as $res)
               {
            ?>
            <tr>
            <th ><?=$i++;?></th>
            <td><?=$res->name?></td>
            <td><?=$res->price?></td>
            <td><?=$res->description?></td>
            <td><img src="<?php echo base_url('images/').$res->image ?>" style="height:15%;width:15%;"></td>
            <td><a class="btn btn-primary" href="<?=base_url('backend/productupdate/').$res->id ?>">Update</a></td>
            <td><a class="btn btn-danger"onclick="return confirm('Are you sure to delete data')" href="<?=base_url('backend/productdelete/').$res->id ?>">Delete</a></td>
            </tr>
            
            <?php
               }
             ?>
        </tbody>
        </table>
</body>
</html>