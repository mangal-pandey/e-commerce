<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Ammount</th>
            <th scope="col">Address</th>
            <th scope="col">Payment Method</th>
            </tr>
        </thead>
        <tbody>
            
            <?php $i=1;?>
            <?php 
              foreach($result as $res)
               {
            ?>
            <tr>
            <th ><?=$i++;?></th>
            <td><?=$res->total_ammount?></td>
            <td><?=$res->address?></td>
            <td><?=$res->payment_method?></td>
            </tr>
            
            <?php
               }
             ?>
        </tbody>
        </table>
</body>
</html>