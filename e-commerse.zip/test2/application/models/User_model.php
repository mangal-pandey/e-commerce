<?php

class User_model extends CI_model{

    public function emailCheck($table,$email)
{
    $this->db->where('email',$email);
   $var= $this->db->get($table);
   return $var->num_rows();
}

public function mobileCheck($table,$mobile)
{
  $this->db->where('phone',$mobile);
  $var= $this->db->get($table);
  return $var->num_rows();
}
}
?>