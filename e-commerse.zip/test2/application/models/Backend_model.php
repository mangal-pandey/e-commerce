<?php 

 class Backend_model extends CI_Model
   {
      public function insertdata($formdata)
       {
         $con= $this->db->insert('user',$formdata) ; 
       }

      public function EmailCheck($email)
       {
          $this->db->where('email',$email);
          $query=$this->db->get('user');
          $result=$query->result();
          if($result>0)
           {
              $row=$query->row();
              $id=$row->id;
              return $id;
           }
         else  
           {
              return 0;
           }

       } 
   
    public function MobileCheck($mobile) 
      {
             
        $this->db->where('mobile',$mobile);
        $query=$this->db->get('user');
        $result=$query->result();
        if($result>0)
         {
            $row=$query->row();
            $id=$row->id;
            return $id;
         }
       else  
         {
            return 0;
         }

    }  

   public function LoginDataCheckAdmin($data)
    {   
        $this->db->where($data);
        $adminquery=$this->db->get('admin');
        $adminresult=$adminquery->num_rows();
         if( $adminresult>0)
          {
            $row_admin= $adminquery->row();
            $id=$row_admin->id;
            return $id;

          }
        else
          {
              return 0;
          }

    } 

    public function LogOut()
     {
         if(isset($_SESSION['user_id']))
          {
            $this->session->unset_userdata('user_id');
             echo "logout user successfully";
          }
         else 
           {
              
              $this->session->unset_userdata('admin_id');
              echo "logout admin successfully";
           }
     }

     public function LoginDataCheckUser($data)
      {
        $this->db->where($data);
        $query=$this->db->get('user');
        $result=$query->num_rows();
        if($result>0)
         {
            $row=$query->row();
            $id=$row->id;
            return $id;
         }
        else 
          {
             return 0;
          }
      }

    public function insertProductData($data)
      {
          $this->db->insert('products',$data);

      }  

      public function GetAllProduct()
       {
        $query = $this->db->get('products');
        $result = $query->result();
        return $result;
       }

      public function GetProduct($id) 
       {
          $this->db->where('id',$id);
          $query=$this->db->get('products');
           $row=$query->row();
           return $row;
       }

      public function updateproductdata( $id,$data)
        {
             $product_id=$id;
             $this->db->where('id', $product_id);
             $this->db->update('products',$data);
        } 

      public function ProductDestory($id)
        {
         $this->db->where('id', $id);
         $con=$this->db->delete('products');
          return $con;
        }  

        public function GetProductData()
          {
            $query = $this->db->get('products');
            $result = $query->result();
            return $result;

          }

         public function DataAddToCart($id) 
           {
               $this->db->where('id',$id);
               $this->db->get('products');
           }
         
          public function InsertCartData($data)
           {
             $con= $this->db->insert('cart_table',$data);
             return $con;

           }

           public function GetAllCartData()
            {
               $user_id=$_SESSION['user_id'];
               $this->db->where('user_id',$user_id);
              $query= $this->db->get('cart_table');
              $result=$query->result();
              return $result;

            }

           public function InsertDataOrderTable($data)
             {
              $this->db->insert('orders', $data);
              $last_inserted_id = $this->db->insert_id();
              return  $last_inserted_id ;
              
             } 

            public function InsertDataOrder_Item_table($data)
             {
                $this->db->insert('order_item_table', $data);
             } 

            public function CartRemoveItem($user_id)
             {
                $this->db->where('user_id',$user_id);
                $this->db->delete('cart_table');
             } 
            
             
           public function GetOrderData()
            {
              $user_id=$_SESSION['user_id'];
              $this->db->where('user_id',$user_id);
             $query= $this->db->get('orders');
             $result=$query->result();
             return $result;
            }  

   }

?>