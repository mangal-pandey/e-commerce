<?php 

class Backend extends CI_Controller
{
 
    public function index()
     {
        $this->load->view('products/index');
     }

     public function registration()
      {
        $this->load->view('products/index');
        $this->load->view('products/registration');
      }

    public function registrationdata()
     {
       if(isset($_POST['submit']))
        {
        $name=$_POST['name'];
        $email=$_POST['email'];
        $mobile=$_POST['mobile'];
        $password=$_POST['password'];
        $address=$_POST['address'];
       
        $this->load->model('Backend_model');
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');



        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
         if($this->form_validation->run()==false)
          {  $this->load->view('products/index');
             $this->load->view('products/registration');
          }
         else if($this->Backend_model->EmailCheck($email))
           {
              $this->session->set_flashdata('error', '!!! This Email Was Early Registered Please Try To Another Email!!!');
              redirect(base_url()."backend/index/");
           } 
         else if($this->Backend_model->MobileCheck($mobile))
           {
              $this->session->set_flashdata('error', '!!! This Mobile Was Early Registered Please Try To Another Mobile!!!');
              redirect(base_url()."backend/index/");
           }     
         else
          {  
            $config['file_name']=time();
            $config['upload_path'] = './images/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $config['max_size']      = 2048;
             $this->load->library('upload', $config);
            if (!$this->upload->do_upload('image')) {
               $formdata=array();
               $formdata['name']=$this->input->post('name');
               $formdata['email']=$this->input->post('email');
               $formdata['mobile']=$this->input->post('mobile');
               $formdata['password']=$this->input->post('password');
               $formdata['address']=$this->input->post('address');
               $this->Backend_model->insertdata( $formdata);
               $this->session->set_flashdata('success', '!!! Data Added Successfully!!!');
                redirect(base_url()."backend/index/");
                 
            } else {
                    $imagedata=  $this->upload->data();
                    $imagename=$imagedata['file_name'];
                    $formdata=array();
                    $formdata['name']=$this->input->post('name');
                    $formdata['email']=$this->input->post('email');
                    $formdata['mobile']=$this->input->post('mobile');
                    $formdata['password']=$this->input->post('password');
                    $formdata['address']=$this->input->post('address');
                    $formdata['image']=$imagename;
                    $this->Backend_model->insertdata( $formdata);
                    $this->session->set_flashdata('success', '!!! Data Added Successfully!!!');
                     redirect(base_url()."backend/index/");
     
                    
            }

             
          } 

         }
       
     }  

    public function login()
    {
       $this->load->view('products/index');
       $this->load->view('products/loginpage');
    } 

    public function logindata()
     {
        $this->load->model('Backend_model');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if($this->form_validation->run()==false)
          {  $this->load->view('products/index');
             $this->load->view('products/loginpage');
          }
        else  
         {
            $email=$_POST['email'];
            $password=$_POST['password'];
            $logindata=array(
               'email'=>$email,
               'password'=>$password,
            );

            $admin_id= $this->Backend_model->LoginDataCheckAdmin($logindata);
            $user_id= $this->Backend_model->LoginDataCheckUser($logindata);
            if($admin_id)
             {
               $this->session->set_userdata('admin_id',$admin_id);
               $this->session->set_flashdata('success', '!!!  Admin Login Successfully!!!');
                     redirect(base_url()."backend/index/");
             }
            else if($user_id)
             {
               $this->session->set_userdata('user_id',$user_id);
               $this->session->set_flashdata('success', '!!! User Login Successfully!!!');
                     redirect(base_url()."backend/index/");  
             }
            else 
              {
               $this->session->set_flashdata('error', '!!! You Are Not Login Successfully!!!');
               redirect(base_url()."backend/index/");
              }

         }

     }

     public function logout()
      {
            $this->load->model('Backend_model');
            $this->Backend_model->LogOut();
           $this->session->set_flashdata('error', '!!! You Are Logout Successfully!!!');
           redirect(base_url()."backend/index/");
       
      }
    
    public function addproduct()
      {
         $this->load->view('products/index');
         $this->load->view('addproduct');

      }  

     public function addproductdata()
      {
         $this->load->model("Backend_model");
         $product_name=$_POST['p_name'];
         $product_price=$_POST['p_price'];
         $product_description=$_POST['p_description'];

         $config['file_name']=time();
         $config['upload_path'] = './images/';
         $config['allowed_types'] = 'gif|jpg|jpeg|png';
         $config['max_size']      = 2048;
          $this->load->library('upload', $config);
         if (!$this->upload->do_upload('p_image')) {
            $formdata=array();
            $formdata['name']=$product_name;
            $formdata['price']= $product_price;
            $formdata['description']= $product_description;
            $this->Backend_model->insertProductData($formdata);
            $this->session->set_flashdata('success', '!!! Product Added Successfully!!!');
             redirect(base_url()."backend/index/");
              
         } else {
                 $imagedata=  $this->upload->data();
                 $imagename=$imagedata['file_name'];
                 $formdata=array();
                 $formdata['name']=$product_name;
                $formdata['price']= $product_price;
                 $formdata['description']= $product_description;
                 $formdata['image']=$imagename;
                 $this->Backend_model->insertProductData($formdata);
                 $this->session->set_flashdata('success', '!!! Product Added Successfully!!!');
                  redirect(base_url()."backend/index/");
  
                 
         }
         
      } 

      public function producttable()
       {
         $this->load->model("Backend_model");
         $data['result']=$this->Backend_model->GetAllProduct();
          $this->load->view('products/index');
          $this->load->view('products/producttable',$data);
       }

     public function productupdate($id)
       {  
         $this->load->model("Backend_model");
         $data=$this->Backend_model->GetProduct($id);
          $this->load->view('products/index');
          $this->load->view('products/updateproduct',['data'=>$data]);
       }  

      public function updateproductdata() 
       {
         $this->load->model('Backend_model');
     
         $config['file_name']=time();
         $config['upload_path'] = './images/';
         $config['allowed_types'] = 'gif|jpg|jpeg|png';
         $config['max_size']      = 2048;
           $this->load->library('upload', $config);
          $this->upload->initialize($config);
                    
         if (!$this->upload->do_upload('p_image')) 
          {
            $formdata=array();      
            $formdata['name']=$this->input->post('p_name');
            $formdata['price']=$this->input->post('p_price');
            $formdata['description']=$this->input->post('p_description');
            $id=$this->input->post('hidden');
            $this->Backend_model->updateproductdata($id,$formdata);
            $this->session->set_flashdata('success', '!!! Data update Successfully!!!');
            $this->load->view('products/index');
            redirect(base_url()."backend/producttable/");
          }
         else 
          {
             $imagedata=  $this->upload->data();
             $imagename=$imagedata['file_name'];
             $formdata=array();      
             $formdata['name']=$this->input->post('p_name');
             $formdata['price']=$this->input->post('p_price');
             $formdata['description']=$this->input->post('p_description');
             $id=$this->input->post('hidden');
            $formdata['image']= $imagename;
            $this->Backend_model->updateproductdata($id,$formdata);
            $this->session->set_flashdata('success', '!!! Data update Successfully!!!');
            $this->load->view('products/index');
            redirect(base_url()."backend/producttable/");
 
 
          }
 
       }


       public function productdelete($id)
        {
           $this->load->model('Backend_model');
          $check=  $this->Backend_model->ProductDestory($id);

          if($check)
            {
           $this->session->set_flashdata('success', '!!! Product Delete Successfully!!!');
            $this->load->view('products/index');
            redirect(base_url()."backend/producttable/");

            }
           else
             {
               $this->session->set_flashdata('error', '!!! Product Not Delete Successfully!!!');
               $this->load->view('products/index');
               redirect(base_url()."backend/producttable/");
             }

 
          
        }

       public function products()
        {
         $this->load->model('Backend_model');
         $data['result']= $this->Backend_model->GetProductData();

           $this->load->view('products/index');
           $this->load->view('products/products',$data);
        }

       public function addtocart()
         {   
            $this->load->model('Backend_model');
            $user_id=$_SESSION['user_id'];
              $cartdata=array(
                'product_name'=>$_POST['product_name'],
                 'product_price'=>$_POST['product_price'],
                 'product_image'=>$_POST['product_image'],
                 'user_id'=>$user_id,
                 'product_id'=>$_POST['product_id']

                );

             $check=$this->Backend_model->InsertCartData($cartdata);

             if($check)
               {
                   $this->session->set_flashdata('success', '!!! Data Add Cart Successfully!!!');
                   $this->load->view('products/index');
                  redirect(base_url()."backend/products/");
               }
             else  
               {
                  $this->session->set_flashdata('error', '!!! Data Not Add Cart Successfully!!!');
                  $this->load->view('products/index');
                  redirect(base_url()."backend/producttable/");
               }
             

         } 

         public function cart()
          {
            $this->load->model('Backend_model');
           $data['result']= $this->Backend_model->GetAllCartData();
           $this->load->view('products/index');
           $this->load->view('carttable',$data);

          }

         public function order()
           {
             $user_id= $_SESSION['user_id'];
            $this->load->model('Backend_model');
                $result=$_POST['item'];
                $sum=0;
                foreach($result as $key=>$res)
                  {
                    
                     $sum=$sum+intval($res[$key]['product_price'])*intval($res[$key]['quntity']);
                     
                  }
                 $order_data=array(
                    'total_ammount'=>$sum,
                    'payment_method'=>$_POST['payment_method'],
                    'address'=>$_POST['address'],
                    'user_id'=>$_SESSION['user_id']
                 ); 

                $order_id=$this->Backend_model->InsertDataOrderTable($order_data);
               
                    foreach($result as $key=>$res)
                    {
                       $order_item=array(
                        'product_id'=>$res[$key]['id'],
                         'quntity'=>$res[$key]['quntity'],
                         'user_id'=>$_SESSION['user_id'],
                         'order_id'=> $order_id,
                       );

                       $this->Backend_model->InsertDataOrder_Item_table( $order_item);
                    }

                    $this->Backend_model->CartRemoveItem($user_id); 

                    $this->session->set_flashdata('success', '!!!Your Order Plased Successfully!!!');
                  $this->load->view('products/index');
                  redirect(base_url()."backend/cart/");

           } 


          public function orders()
           {
            $this->load->model('Backend_model');
            $data['result']= $this->Backend_model->GetOrderData();
            $this->load->view('products/index');
            $this->load->view('products/orderstable',$data);
           } 

}

?>